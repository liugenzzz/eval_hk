# 开放问答(装备描述)评估通路 — 使用说明

适用场景:对 ShareGPT 格式的装备描述问答数据(单轮/多轮、单图/多图),评估 Qwen3-VL-8B-Instruct 等模型的开放问答能力。只跑 vqa,不涉及 mcq/judge 选择判断题。

---

## 〇、重要:哪些东西要重新生成

如果你之前用旧版本跑过,以下三样**全部作废重来**:

| 东西 | 为什么 |
|------|--------|
| `aero_vqa.tsv` | 新版多了 `history` 列;`question` 列只放当前轮问题(旧版是拼接文本);`category` 列填 `单轮/多轮`(旧版为空) |
| 推理结果 xlsx | 旧结果是旧提示词+旧格式跑的,和新 TSV 对不上 |
| 裁判缓存(`cache_dir` 里的 `judge_cache_*.jsonl`) | 提示词换了,命中旧缓存的题不会按新标准重判 |

---

## 一、数据转换:JSON → TSV

```bash
python -m eval_tool.convert_vqa_json <sharegpt格式.json> <输出目录>
# 例:
python -m eval_tool.convert_vqa_json /code/data/zb_sharegpt.json /code/LMUData
```

- 在输出目录生成 `aero_vqa.tsv`,该目录就是后面配置里的 `tsv_dir`
- JSON 里 `image` 字段的图片路径必须在本机可读(会读文件转 base64 内嵌进 TSV)
- 多轮记录按轮拆行:每轮一行,当前轮问题放 `question`,之前轮次存进 `history`(JSON 结构,含每轮问/标准答案/图数)
- 多图:`image` 列存"到当前轮为止出现过的所有图"(JSON 数组 base64)
- `category` 列自动标 `单轮`(无历史)/`多轮`(有历史)

## 二、推理:生成预测文件

配置参考 `infer_config.example.json`,要点:

```json
{
  "infer": {
    "model_name": "base",
    "model_path": "/code/trainspace/.../Qwen3-VL-8B-Instruct",
    "tsv_dir": "/code/LMUData",
    "out_dir": "/code/eval_model_output/zb_base",
    "datasets": { "vqa": "aero_vqa" },
    "prompt_files": { "vqa": "prompts/infer_vqa_raw.txt" },
    "max_new_tokens": 1024
  }
}
```

```bash
python -m eval_tool.run_infer --config infer_config.json
```

说明:
- **`datasets` 只写 vqa 就只跑 vqa**(不会再去找 aero_mcq.tsv)
- **`prompt_files` 必须显式配置**,留空会掉进内置的航空图纸版默认提示词(不适合装备数据)
  - `prompts/infer_vqa_raw.txt`:裸问题直出,**推荐**(与 sft 训练分布一致)
  - `prompts/infer_vqa_equip.txt`:装备领域指令包装版,base 模型答得太散时可试
- `max_new_tokens` 建议 1024(参考答案普遍 500-800 字,512 易截断)
- 多轮行推理时自动回放成真正的多轮对话(user/assistant 交替,历史答案用标准答案,图片挂在对应轮次),Qwen3-VL 32K 上下文足够,无需其他参数
- 进度:先打 `[infer] 读取数据集...`(TSV 内嵌图片,大文件读得慢属正常),再打 `[infer] 共 N 条`,推理中每约 1% 打一行 `[Infer aero_vqa] n/N`,适合 nohup 日志
- 每个模型跑一次(改 model_name/model_path/out_dir),产出 `<模型名>_aero_vqa.xlsx`
- 如果预测结果是别处生成的,自备 xlsx 也行:至少含 `index` 和 `prediction` 两列,index 与 TSV 对齐

## 三、评分:出总分报告

配置参考 `config.example.json`,要点:

```json
{
  "tsv_dir": "/code/LMUData",
  "out_dir": "eval_report",
  "cache_dir": "eval_cache",
  "datasets": { "vqa": "aero_vqa" },
  "models": [
    { "name": "base", "vqa": "/code/eval_model_output/zb_base/base_aero_vqa.xlsx" },
    { "name": "sft",  "vqa": "/code/eval_model_output/zb_sft/sft_aero_vqa.xlsx" }
  ],
  "baseline_model": "base",
  "enabled_datasets": ["vqa"],
  "judge": {
    "api_base": "http://192.168.48.7:18180/v1/chat/completions",
    "model": "qwen3.6-27b",
    "prompt_files": {
      "pointwise": "prompts/judge_equip_pointwise.txt",
      "pairwise": "prompts/judge_equip_pairwise.txt"
    }
  }
}
```

```bash
python -m eval_tool.run_eval --config config.json
```

说明:
- 裁判提示词用装备版 `judge_equip_*`(参考答案为事实基准 + 图片为外观基准 + INA 防编造 + 长度中性;按 MT-Bench/MM-Vet 框架写)
- 旧的 `judge_vqa_*` 是航空图纸场景的,这批数据不要用
- 多轮行判分时,裁判会看到"第N轮问/第N轮答 + 当前问题"的完整上下文,但只判当前轮
- `category_weights` 不用配(单轮/多轮默认等权;想调权重可写 `{"单轮": 1.0, "多轮": 2.0}` 这样)

### 复用某个模型已经跑过的评分结果(不用每次都重判 baseline)

`baseline_model`(比如 `base`)如果预测结果没变,没必要每次评新模型时都重新调一遍裁判 API。给该模型加一个 `scored` 字段,指向它上一次跑出来的 `detail_<模型名>_<数据集>.xlsx`,那一项就会跳过读预测文件、跳过裁判调用,直接读文件里已有的 `hit`/`judge_reason` 等结果:

```json
{
  "models": [
    { "name": "base", "scored": { "vqa": "eval_report_prev/detail_base_vqa.xlsx" } },
    { "name": "sft_ep2", "vqa": "/code/eval_model_output/zb_sft_ep2/sft_ep2_aero_vqa.xlsx" }
  ]
}
```

- 一个模型可以同时配 `vqa`(原始预测路径)和 `scored`(已评分结果路径);两者都配时 `scored` 优先,`vqa` 会被忽略。
- 复用的文件必须是本工具自己产出的 `detail_*.xlsx`(或从 `judge_detail_all.xlsx` 按 model 筛出来的子集),至少要有 `index/question/answer/prediction/category/l2-category/hit/judge_reason/pred_len` 这些列——正常跑一次输出的文件就是这个格式,不用手动改。
- 和裁判缓存(`judge_cache_pointwise.jsonl`)的区别:缓存是按 index 命中、换 prompt 会自动失效重判;`scored` 是整份文件直接读,换了裁判提示词也不会重判,想让 baseline 也用上新提示词就把 `scored` 去掉、走一遍正常评分。

## 四、看结果

跑完终端直接打印总分表,文件在 `out_dir`:

| 文件 | 内容 |
|------|------|
| **`score_summary.csv`** | 每模型一行:`total_score` + `单轮`/`多轮` 分列及样本数 |
| **`judge_detail_all.xlsx`** | 所有模型的裁判逐题结果合并在一个文件(model/question/answer/prediction/hit/judge_reason) |
| `pairwise_vs_baseline.csv` | 对 baseline 的胜/平/负率,按单轮/多轮拆分 |
| `report_summary*.csv/json` | 各维度得分+置信区间 |
| `detail_*.xlsx` | 单模型逐题明细(按模型分文件的版本) |
| `warnings.log` | 缺预测、对不上号等警告(如有) |

## 五、跑不通先干这个

```bash
python e2e_check.py
```

不需要 GPU、不需要裁判 API,用假模型+假裁判把"转换→推理→评分→报告"整条通路过一遍(覆盖单轮单图/多轮多图/单轮多图)。它能过,说明代码和环境没问题,问题在你的数据或配置;它不能过,把报错发出来。

常见坑:
1. **缺 openpyxl**:`pip install openpyxl`(写 xlsx 必需)
2. 图片路径读不到:JSON 里的路径要在运行机器上真实存在
3. 换了提示词没清 `cache_dir` 裁判缓存 → 分数不更新
4. `prompt_files` 忘了配 → 掉进航空图纸版默认提示词
5. 权重加载完"没动静":先等 `[infer] 读取数据集`(大 TSV 读几分钟正常),看到 `[Infer aero_vqa] n/N` 在走就没卡

## 六、多轮评估的口径(设计决策记录)

- 多轮按轮拆行,每轮单独打分;`score_summary` 里"多轮"列 = 所有带上下文轮次的平均分
- 历史用**标准答案**回放(gold context):每轮独立、可并行、可缓存,前面答错不连累后面;代价是不考察"模型自己答错后能否接住"——如需真实连续对话模式,是另一套设计
- 第一轮记作"单轮"(它没有上下文,考察条件与单轮题相同)
